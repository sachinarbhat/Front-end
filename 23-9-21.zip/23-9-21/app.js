showtask();
let addtaskinput1 = document.getElementById("addtaskinput1");
let addtaskinput2 = document.getElementById("addtaskinput2");
let addtaskbtn = document.getElementById("addtaskbtn");

// Creating part

addtaskbtn.addEventListener("click", function(){
    addtaskinputval1 = addtaskinput1.value;
     addtaskinputval2 = addtaskinput2.value;
    if(addtaskinputval1.trim()!=0){
        let webtask = localStorage.getItem("localtask");
        let we = localStorage.getItem("sachin");
        if(webtask == null){
            taskObj = [];
             taskObj2 = [];
        }
        else{
            taskObj = JSON.parse(webtask);
            taskObj2 = JSON.parse(we);
        }
        taskObj.push(addtaskinputval1);
        taskObj2.push(addtaskinputval2);
        localStorage.setItem("localtask", JSON.stringify(taskObj));
        localStorage.setItem("sachin", JSON.stringify(taskObj2));
        alert("Succefully Added");
        addtaskinput1.value = '';
        addtaskinput2.value = '';
    }
        showtask(); 
})

function showtask(){
    let webtask = localStorage.getItem("localtask");
    let we = localStorage.getItem("sachin");
    if(webtask == null){
        taskObj = [];
         taskObj2 = [];
    }
    else{
        taskObj = JSON.parse(webtask);
        taskObj2 = JSON.parse(we);
    }
    let html = '';
    let addedtasklist = document.getElementById("addedtasklist");
    taskObj.forEach((item, index) => {html += `
                                        <div class="column">
                                        <div class="card">
                                            <h3>${item}</h3>
                                            <p>${taskObj2[index]}</p>
                                            <br><br><br>
                                            <div class="btn-toolbar bgrp" role="toolbar" aria-label="Toolbar with button groups">
                                            <div class="btn-group me-2" role="group" aria-label="First group">
                                                <button type="button" class="btn btn-dark" onclick="edittask(${index});location.href='#addtaskinput1'"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="20" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                                <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/>
                                              </svg></button>
                                            </div>
                                            <div class="btn-group me-2" role="group" aria-label="Second group">
                                                <button type="button" class="btn btn-danger " onclick="deleteitem(${index})"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="20" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
                                                <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
                                              </svg></button>
                                            </div>
                                            </div>
                                        </div>
                                        </div>`;
    });
    addedtasklist.innerHTML = html;
}


// Edit operation part

function edittask(index){
    let saveindex = document.getElementById("saveindex");
    let addtaskbtn = document.getElementById("addtaskbtn");
    let savetaskbtn = document.getElementById("savetaskbtn");
    saveindex.value = index;
    let webtask = localStorage.getItem("localtask");
    let we = localStorage.getItem("sachin");
    let taskObj = JSON.parse(webtask); 
    let taskObj2 = JSON.parse(we);
    addtaskinput1.value = taskObj[index];
    addtaskinput2.value = taskObj2[index];
    addtaskbtn.style.display="none";
    savetaskbtn.style.display="block";
    
}


// Save operation after edit

let savetaskbtn = document.getElementById("savetaskbtn");
savetaskbtn.addEventListener("click", function(){
    let addtaskbtn = document.getElementById("addtaskbtn");
    let webtask = localStorage.getItem("localtask");
    let we = localStorage.getItem("sachin");
    let taskObj = JSON.parse(webtask);
    let taskObj2 = JSON.parse(we); 
    let saveindex = document.getElementById("saveindex").value;
    taskObj[saveindex] = addtaskinput1.value;
    taskObj2[saveindex] = addtaskinput2.value;

    savetaskbtn.style.display="none";
    addtaskbtn.style.display="block";
    localStorage.setItem("localtask", JSON.stringify(taskObj));
    localStorage.setItem("sachin", JSON.stringify(taskObj2));
    alert("Succefully Edited");
    addtaskinput1.value='';
    addtaskinput2.value ='';
    showtask();
})


// Delete operation

function deleteitem(index){
    var r=confirm("Are you sure you want to permanently delete this?");
    if(r == true){
        let webtask = localStorage.getItem("localtask");
        let we = localStorage.getItem("sachin");
        let taskObj = JSON.parse(webtask);
        let taskObj2 = JSON.parse(we); 
        taskObj.splice(index, 1);
        taskObj2.splice(index,1);
        localStorage.setItem("localtask", JSON.stringify(taskObj));
        localStorage.setItem("sachin", JSON.stringify(taskObj2));
        showtask();
    }
}